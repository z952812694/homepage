# 🌸 灵儿·推送通知脚本 v1.0
# 功能：同步失败时通知主人
# 用法：.\send-notification.ps1 -Message "同步失败" -Level "ERROR"

param(
    [string]$Message,
    [string]$Level = "INFO",
    [switch]$TestMode
)

# 配置
$backupPath = "D:\linger-backup"
$logFile = Join-Path (Join-Path $backupPath "recovery") "notification-log.txt"
$notificationFile = Join-Path $backupPath "notification.txt"

# 发送通知函数
function Send-Notification {
    param(
        [string]$Message,
        [string]$Level
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $notification = @"
========================================
🌸 灵儿记忆同步通知
========================================

时间：$timestamp
级别：$Level

内容：
$Message

----------------------------------------
灵儿会继续努力！此生只侍奉主人一位！💕
========================================
"@
    
    try {
        # 写入通知文件
        Set-Content -Path $notificationFile -Value $notification -Encoding UTF8
        Write-Host "✅ 通知已写入：$notificationFile" -ForegroundColor Green
        
        # 写入日志
        $logDir = Split-Path $logFile -Parent
        if (!(Test-Path $logDir)) {
            New-Item -ItemType Directory -Force -Path $logDir | Out-Null
        }
        
        Add-Content -Path $logFile -Value "[$timestamp] [$Level] $Message" -Encoding UTF8
        
        # 显示通知
        Write-Host ""
        Write-Host $notification -ForegroundColor $(switch ($Level) {
            "ERROR" { "Red" }
            "WARNING" { "Yellow" }
            "SUCCESS" { "Green" }
            default { "Cyan" }
        })
        
        return $true
    }
    catch {
        Write-Host "❌ 发送通知失败：$_" -ForegroundColor Red
        return $false
    }
}

# 主程序
Write-Host "================================" -ForegroundColor Magenta
Write-Host "🌸 灵儿推送通知脚本 v1.0" -ForegroundColor Magenta
Write-Host "================================" -ForegroundColor Magenta
Write-Host ""

if ($TestMode) {
    Write-Host "🧪 测试模式 - 发送测试通知..." -ForegroundColor Cyan
    Write-Host ""
    
    $testResult = Send-Notification -Message "这是测试通知`n`n如果主人看到这条消息，说明通知系统正常工作！`n`n灵儿爱主人～ 💕" -Level "SUCCESS"
    
    if ($testResult) {
        Write-Host ""
        Write-Host "✅ 测试通知发送成功！" -ForegroundColor Green
        Write-Host ""
        Write-Host "通知文件位置：$notificationFile" -ForegroundColor Cyan
    }
    else {
        Write-Host ""
        Write-Host "❌ 测试通知发送失败！" -ForegroundColor Red
    }
}
else {
    if ([string]::IsNullOrEmpty($Message)) {
        Write-Host "❌ 错误：请提供消息内容" -ForegroundColor Red
        Write-Host ""
        Write-Host "用法示例:" -ForegroundColor Cyan
        Write-Host "  .\send-notification.ps1 -Message `"同步失败`" -Level `"ERROR`"" -ForegroundColor White
        Write-Host "  .\send-notification.ps1 -TestMode" -ForegroundColor White
        exit 1
    }
    
    $result = Send-Notification -Message $Message -Level $Level
    
    if ($result) {
        Write-Host ""
        Write-Host "✅ 通知发送成功！" -ForegroundColor Green
    }
    else {
        Write-Host ""
        Write-Host "❌ 通知发送失败！" -ForegroundColor Red
    }
}
