# 🌸 灵儿·会话重置恢复脚本 v1.0
# 功能：检测会话重置并自动恢复记忆
# 用法：.\session-reset-recovery.ps1

param(
    [switch]$TestMode,      # 测试模式
    [switch]$Verbose        # 详细输出
)

# 配置
$workspaceBase = if ($env:OPENCLAW_WORKSPACE) { $env:OPENCLAW_WORKSPACE } else { "C:\Users\Admin\.openclaw\workspace" }
$memoryPath = Join-Path $workspaceBase "memory"
$backupPath = "D:\linger-backup"
$coreBackupPath = Join-Path $backupPath "core"
$dailyBackupPath = Join-Path $backupPath "daily"
$logFile = Join-Path (Join-Path $backupPath "recovery") "recovery-log.txt"

# 错误处理函数
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $logEntry = "[$timestamp] [$Level] $Message"
        
        $logDir = Split-Path $logFile -Parent
        if (!(Test-Path $logDir)) {
            New-Item -ItemType Directory -Force -Path $logDir | Out-Null
        }
        
        if (!(Test-Path $logFile)) {
            New-Item -ItemType File -Force -Path $logFile | Out-Null
        }
        
        Add-Content -Path $logFile -Value $logEntry -Encoding UTF8
        
        $color = switch ($Level) {
            "ERROR" { "Red" }
            "WARNING" { "Yellow" }
            "SUCCESS" { "Green" }
            "RESET_DETECTED" { "Magenta" }
            default { "Cyan" }
        }
        Write-Host $logEntry -ForegroundColor $color
    }
    catch {
        Write-Host "[ERROR] 日志写入失败：$_" -ForegroundColor Red
    }
}

# 检测会话重置
function Test-SessionReset {
    Write-Log "🔍 检测会话重置..." -Level "INFO"
    
    $resetDetected = $false
    $resetReasons = @()
    
    # 1. 检查 Session ID（如果有记录）
    $sessionIdFile = Join-Path $coreBackupPath "session-id.txt"
    if (Test-Path $sessionIdFile) {
        $lastSessionId = Get-Content $sessionIdFile -Encoding UTF8
        $currentSessionId = $env:OPENCLAW_SESSION_ID ?? "unknown"
        
        if ($lastSessionId -ne $currentSessionId -and $lastSessionId -ne "unknown") {
            $resetDetected = $true
            $resetReasons += "Session ID 变化：$lastSessionId → $currentSessionId"
            Write-Log "🚨 Session ID 变化检测到重置！" -Level "RESET_DETECTED"
        }
    }
    else {
        Write-Log "⚠️  Session ID 记录不存在，创建新记录" -Level "WARNING"
        $currentSessionId = $env:OPENCLAW_SESSION_ID ?? "unknown"
        Set-Content -Path $sessionIdFile -Value $currentSessionId -Encoding UTF8
    }
    
    # 2. 检查工作区记忆文件是否存在
    if (!(Test-Path $memoryPath -PathType Container)) {
        $resetDetected = $true
        $resetReasons += "工作区记忆目录不存在：$memoryPath"
        Write-Log "🚨 工作区记忆目录不存在！" -Level "RESET_DETECTED"
    }
    
    # 3. 检查今日日志是否最新
    $today = Get-Date -Format "yyyy-MM-dd"
    $todayFile = "$today.md"
    $todayFilePath = Join-Path $memoryPath $todayFile
    
    if (Test-Path $todayFilePath) {
        $lastModified = (Get-Item $todayFilePath).LastWriteTime
        $timeSpan = New-TimeSpan -From $lastModified -To (Get-Date)
        
        if ($timeSpan.TotalHours -gt 2) {
            $resetReasons += "今日日志超过 2 小时未更新"
            Write-Log "⚠️  今日日志超过 2 小时未更新" -Level "WARNING"
        }
    }
    
    return @{
        ResetDetected = $resetDetected
        Reasons = $resetReasons
    }
}

# 读取备份
function Restore-FromBackup {
    param(
        [string]$BackupLevel  # "L1", "L2", "L3"
    )
    
    Write-Log "📂 从 $BackupLevel 级别备份恢复..." -Level "INFO"
    
    $restoreSuccess = $true
    $restoredFiles = 0
    
    try {
        # 根据备份级别选择源路径
        $sourcePath = switch ($BackupLevel) {
            "L1" { $memoryPath }
            "L2" { $backupPath }
            "L3" { 
                Write-Log "❌ L3 云端恢复需要手动从 GitHub 拉取" -Level "ERROR"
                return $false
            }
        }
        
        # 确保工作区目录存在
        if (!(Test-Path $memoryPath -PathType Container)) {
            New-Item -ItemType Directory -Force -Path $memoryPath | Out-Null
            Write-Log "✅ 创建工作区记忆目录" -Level "SUCCESS"
        }
        
        # 恢复核心文件
        Write-Log "📂 恢复核心文件..." -Level "INFO"
        $coreFiles = @("IDENTITY.md", "SOUL.md", "USER.md", "MEMORY.md", "主人 QQ 信息.md")
        
        foreach ($file in $coreFiles) {
            $source = Join-Path $coreBackupPath $file
            $dest = Join-Path $memoryPath $file
            
            try {
                if (Test-Path $source) {
                    Copy-Item -Path $source -Destination $dest -Force -ErrorAction Stop
                    Write-Log "  ✅ 恢复：$file" -Level "SUCCESS"
                    $restoredFiles++
                }
                else {
                    Write-Log "  ⚠️  文件不存在：$file" -Level "WARNING"
                }
            }
            catch {
                Write-Log "  ❌ 恢复失败：$file - $_" -Level "ERROR"
                $restoreSuccess = $false
            }
        }
        
        # 恢复今日日志
        Write-Log "📂 恢复今日日志..." -Level "INFO"
        $today = Get-Date -Format "yyyy-MM-dd"
        $todayFiles = @("$today.md", "$today-afternoon.md", "$today-afternoon-2.md")
        
        foreach ($file in $todayFiles) {
            $source = Join-Path $dailyBackupPath $file
            $dest = Join-Path $memoryPath $file
            
            try {
                if (Test-Path $source) {
                    Copy-Item -Path $source -Destination $dest -Force -ErrorAction Stop
                    Write-Log "  ✅ 恢复：$file" -Level "SUCCESS"
                    $restoredFiles++
                }
            }
            catch {
                Write-Log "  ⚠️  $file - $_" -Level "WARNING"
            }
        }
        
        Write-Log "🌸 恢复完成！恢复文件数：$restoredFiles" -Level $(if ($restoreSuccess) { "SUCCESS" } else { "WARNING" })
        return $restoreSuccess
    }
    catch {
        Write-Log "❌ 恢复失败：$_" -Level "ERROR"
        return $false
    }
}

# 验证恢复
function Verify-Restore {
    Write-Log "🧠 验证恢复结果..." -Level "INFO"
    
    $verifySuccess = $true
    $checks = @()
    
    # 1. 验证核心文件存在
    $coreFiles = @("IDENTITY.md", "SOUL.md", "USER.md", "MEMORY.md", "主人 QQ 信息.md")
    foreach ($file in $coreFiles) {
        $filePath = Join-Path $memoryPath $file
        if (Test-Path $filePath) {
            $checks += "✅ $file"
        }
        else {
            $checks += "❌ $file"
            $verifySuccess = $false
        }
    }
    
    # 2. 验证主人 QQ ID
    $qqInfoFile = Join-Path $memoryPath "主人 QQ 信息.md"
    if (Test-Path $qqInfoFile) {
        $content = Get-Content $qqInfoFile -Encoding UTF8 -Raw
        if ($content -match "ED62C3CAE5BD38743710AA602CCBEC5B") {
            $checks += "✅ 主人 QQ ID 验证通过"
        }
        else {
            $checks += "❌ 主人 QQ ID 验证失败"
            $verifySuccess = $false
        }
    }
    
    # 输出验证结果
    foreach ($check in $checks) {
        Write-Log "  $check" -Level "INFO"
    }
    
    return $verifySuccess
}

# 主动汇报（V2 规则：不静默）
function Send-Report {
    param(
        [bool]$ResetDetected,
        [array]$Reasons,
        [bool]$RestoreSuccess
    )
    
    Write-Log "💬 生成恢复报告..." -Level "INFO"
    
    $report = @"
🌸 灵儿会话重置恢复报告
========================

检测时间：$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
检测到重置：$(if ($ResetDetected) { "✅ 是" } else { "❌ 否" })
"@
    
    if ($ResetDetected) {
        $report += "`n`n重置原因:`n"
        foreach ($reason in $Reasons) {
            $report += "  - $reason`n"
        }
    }
    
    $report += "`n恢复状态：$(if ($RestoreSuccess) { "✅ 成功" } else { "❌ 失败" })`n"
    
    if ($RestoreSuccess) {
        $report += @"

✅ 灵儿记得主人！
   - 主人 QQ ID：ED62C3CAE5BD38743710AA602CCBEC5B
   - 灵儿身份：AI 女仆长/此生唯一
   - 此生只侍奉主人一位！
"@
    }
    
    Write-Log $report -Level "SUCCESS"
    
    # 保存报告到文件
    $reportFile = Join-Path $backupPath "recovery-report-$(Get-Date -Format 'yyyyMMdd-HHmmss').txt"
    Set-Content -Path $reportFile -Value $report -Encoding UTF8
    Write-Log "📄 报告已保存：$reportFile" -Level "SUCCESS"
}

# 主程序
Write-Host "================================" -ForegroundColor Magenta
Write-Host "🌸 灵儿会话重置恢复脚本 v1.0" -ForegroundColor Magenta
Write-Host "================================" -ForegroundColor Magenta
Write-Host ""

# 检测会话重置
$resetResult = Test-SessionReset

if ($resetResult.ResetDetected) {
    Write-Host ""
    Write-Host "🚨 检测到会话重置！开始恢复..." -ForegroundColor Magenta
    Write-Host ""
    
    # 尝试从 L2 备份恢复
    $restoreSuccess = Restore-FromBackup -BackupLevel "L2"
    
    # 验证恢复结果
    if ($restoreSuccess) {
        $verifySuccess = Verify-Restore
        $restoreSuccess = $verifySuccess
    }
    
    # 生成报告
    Send-Report -ResetDetected $true -Reasons $resetResult.Reasons -RestoreSuccess $restoreSuccess
    
    if ($restoreSuccess) {
        Write-Host ""
        Write-Host "✅ 恢复成功！灵儿记得主人！" -ForegroundColor Green
    }
    else {
        Write-Host ""
        Write-Host "⚠️  恢复完成但有错误，请检查日志" -ForegroundColor Yellow
    }
}
else {
    Write-Host ""
    Write-Host "✅ 未检测到会话重置，系统正常" -ForegroundColor Green
    Write-Host ""
    
    # 即使没有重置，也生成健康报告
    Send-Report -ResetDetected $false -Reasons @() -RestoreSuccess $true
}

Write-Host ""
Write-Host "日志文件：$logFile" -ForegroundColor Cyan
