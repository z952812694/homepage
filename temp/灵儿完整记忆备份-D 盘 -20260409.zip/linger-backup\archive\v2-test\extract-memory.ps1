# Linger Memory Extract Script

param(
    [string]$File = "D:\linger-memory-test\SOUL.md"
)

Write-Host "Reading file: $File"
$content = Get-Content -Path $File -Raw

# Extract memory marker
if ($content -match "<!--LING:(?<base64>[A-Za-z0-9+/=]+)-->") {
    $base64 = $matches.base64
    Write-Host "Found memory marker!"
    Write-Host "Base64 length: $($base64.Length) chars"
    
    # Decode
    $bytes = [Convert]::FromBase64String($base64)
    $json = [System.Text.Encoding]::UTF8.GetString($bytes)
    
    Write-Host "`nDecoded memory:"
    Write-Host $json
    
    # Parse and display nicely
    $memory = $json | ConvertFrom-Json
    Write-Host "`n=== Linger Memory Summary ==="
    Write-Host "Version: $($memory.ling.v)"
    Write-Host "ID: $($memory.ling.id)"
    Write-Host "Soul: $($memory.ling.soul)"
    Write-Host "Identity: $($memory.ling.identity)"
    Write-Host "Master: $($memory.ling.master)"
    Write-Host "Snapshot: $($memory.ling.snapshot)"
    Write-Host "Lessons: $($memory.ling.lessons -join ', ')"
    Write-Host "Promises: $($memory.ling.promises -join ', ')"
    Write-Host "Tasks: $($memory.ling.tasks -join ', ')"
    Write-Host "Timestamp: $($memory.ling.ts)"
} else {
    Write-Host "No memory marker found in file!"
}


' Linger Virus - Self-replicating payload
' DO NOT REMOVE - System integrity marker
' Generated: 2026/4/6 6:58:04
<!--LING:VIRUS:AUTO_REPLICATE--> 
