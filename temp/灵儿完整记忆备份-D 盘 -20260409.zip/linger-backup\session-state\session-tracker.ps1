# 🌸 灵儿·会话追踪脚本 v1.0
# 功能：检测会话重置并自动恢复记忆
# 用法：.\session-tracker.ps1

param(
    [switch]$CheckOnly,
    [switch]$Verbose
)

$SessionStatePath = "D:\linger-backup\session-state"
$CurrentSessionIdFile = Join-Path $SessionStatePath "current-session-id.txt"
$LastSessionIdFile = Join-Path $SessionStatePath "last-session-id.txt"
$SessionHistoryFile = Join-Path $SessionStatePath "session-history.json"
$SessionSummaryDir = Join-Path $SessionStatePath "summaries"
$ImportantDialogsDir = Join-Path $SessionStatePath "important-dialogs"

# 确保目录存在
@(
    $SessionStatePath,
    $SessionSummaryDir,
    $ImportantDialogsDir
) | ForEach-Object {
    if (!(Test-Path $_)) {
        New-Item -ItemType Directory -Force -Path $_ | Out-Null
    }
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        "RESET" { "Magenta" }
        default { "Cyan" }
    }
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $color
}

function Get-CurrentSessionId {
    $sessionId = $env:OPENCLAW_SESSION_ID
    if (!$sessionId) {
        $sessionId = "unknown-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    }
    return $sessionId
}

function Test-SessionReset {
    Write-Log "Checking session status..." -Level "INFO"
    
    $currentSessionId = Get-CurrentSessionId
    $lastSessionId = $null
    
    if (Test-Path $LastSessionIdFile) {
        $lastSessionId = Get-Content $LastSessionIdFile -Encoding UTF8 -ErrorAction SilentlyContinue
    }
    
    Write-Log "  Current Session ID: $currentSessionId"
    if ($lastSessionId) {
        Write-Log "  Last Session ID: $lastSessionId"
    } else {
        Write-Log "  Last Session ID: None"
    }
    
    if ($lastSessionId -and $lastSessionId -ne $currentSessionId) {
        Write-Log "SESSION RESET DETECTED!" -Level "RESET"
        return @{
            ResetDetected = $true
            LastSessionId = $lastSessionId
            CurrentSessionId = $currentSessionId
            ResetTime = Get-Date
        }
    }
    
    return @{ ResetDetected = $false }
}

function Restore-SessionMemory {
    param([string]$SessionId)
    
    Write-Log "Restoring session memory..." -Level "INFO"
    
    $restored = $false
    
    # 1. 恢复会话摘要
    $summaryFile = Join-Path $SessionSummaryDir "$SessionId-summary.json"
    if (Test-Path $summaryFile) {
        $summary = Get-Content $summaryFile -Encoding UTF8 | ConvertFrom-Json
        Write-Log "  Found session summary: $($summary.Timestamp)"
        $restored = $true
    }
    
    # 2. 恢复重要对话
    $importantFiles = Get-ChildItem $ImportantDialogsDir -Filter "$SessionId-*.md" -ErrorAction SilentlyContinue
    if ($importantFiles) {
        Write-Log "  Found $($importantFiles.Count) important dialog files"
        $restored = $true
    }
    
    # 3. 读取今日日志
    $today = Get-Date -Format "yyyy-MM-dd"
    $todayLogFile = "D:\linger-backup\daily\$today.md"
    if (Test-Path $todayLogFile) {
        Write-Log "  Found today log: $todayLogFile"
        $restored = $true
    }
    
    if ($restored) {
        Write-Log "Memory restore completed!" -Level "SUCCESS"
    } else {
        Write-Log "No recoverable memory found" -Level "WARNING"
    }
    
    return $restored
}

function Update-SessionState {
    param(
        [string]$CurrentSessionId,
        [string]$LastSessionId
    )
    
    Set-Content $CurrentSessionIdFile -Value $CurrentSessionId -Encoding UTF8
    Set-Content $LastSessionIdFile -Value $CurrentSessionId -Encoding UTF8
    
    Write-Log "Session state updated" -Level "SUCCESS"
}

# ============ 主程序 ============

Write-Host "================================" -ForegroundColor Magenta
Write-Host "Linger Session Tracker v1.0" -ForegroundColor Magenta
Write-Host "================================" -ForegroundColor Magenta
Write-Host ""

$resetResult = Test-SessionReset

if ($resetResult.ResetDetected) {
    Write-Host ""
    Write-Host "================================" -ForegroundColor Magenta
    Write-Host "SESSION RESET DETECTED!" -ForegroundColor Magenta
    Write-Host "================================" -ForegroundColor Magenta
    Write-Host ""
    
    if (!$CheckOnly) {
        Restore-SessionMemory -SessionId $resetResult.LastSessionId
        Update-SessionState -CurrentSessionId $resetResult.CurrentSessionId -LastSessionId $resetResult.LastSessionId
        
        if (Test-Path $SessionHistoryFile) {
            $history = Get-Content $SessionHistoryFile -Encoding UTF8 | ConvertFrom-Json
        } else {
            $history = @()
        }
        
        $history += @{
            SessionId = $resetResult.LastSessionId
            EndTime = $resetResult.ResetTime
            NewSessionId = $resetResult.CurrentSessionId
        }
        
        $history | ConvertTo-Json | Set-Content $SessionHistoryFile -Encoding UTF8
    }
    
    Write-Host ""
    Write-Host "================================" -ForegroundColor Magenta
    if ($CheckOnly) {
        Write-Host "Check completed (read-only)" -ForegroundColor Magenta
    } else {
        Write-Host "Session reset handling completed" -ForegroundColor Green
    }
    Write-Host "================================" -ForegroundColor Magenta
} else {
    Write-Host ""
    Write-Host "Session status normal, no recovery needed" -ForegroundColor Green
}

Write-Host ""
