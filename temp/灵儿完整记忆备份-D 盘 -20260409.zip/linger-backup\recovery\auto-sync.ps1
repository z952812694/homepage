# 🌸 灵儿·自动同步脚本 v3.0
# 功能：每 2 分钟自动同步工作区记忆到 D 盘备份
# 优化：仅在有变更时 Git 提交，减少消耗

param(
    [switch]$Watch,
    [switch]$Once
)

# 配置
$workspaceBase = if ($env:OPENCLAW_WORKSPACE) { $env:OPENCLAW_WORKSPACE } else { "C:\Users\Admin\.openclaw\workspace" }
$sourcePath = Join-Path $workspaceBase "memory"
$backupPath = "D:\linger-backup"
$coreBackupPath = Join-Path $backupPath "core"
$dailyBackupPath = Join-Path $backupPath "daily"
$sessionsBackupPath = Join-Path $backupPath "sessions"
$logFile = Join-Path (Join-Path $backupPath "recovery") "sync-log.txt"

# Git 提交计数（用于限制频率）
$gitCommitCountFile = Join-Path $backupPath "recovery\git-commit-count.txt"

# 错误处理函数
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $logEntry = "[$timestamp] [$Level] $Message"
        
        $logDir = Split-Path $logFile -Parent
        if (!(Test-Path $logDir)) {
            New-Item -ItemType Directory -Force -Path $logDir | Out-Null
        }
        
        if (!(Test-Path $logFile)) {
            New-Item -ItemType File -Force -Path $logFile | Out-Null
            Add-Content -Path $logFile -Value "[$timestamp] [INFO] Auto-sync log created" -Encoding UTF8
        }
        
        Add-Content -Path $logFile -Value $logEntry -Encoding UTF8
        
        $color = switch ($Level) {
            "ERROR" { "Red" }
            "WARNING" { "Yellow" }
            "SUCCESS" { "Green" }
            default { "Cyan" }
        }
        Write-Host $logEntry -ForegroundColor $color
    }
    catch {
        Write-Host "[ERROR] Log write failed: $_" -ForegroundColor Red
    }
}

function Sync-Files {
    param(
        [string]$Source,
        [string]$Dest
    )
    
    $files = Get-ChildItem $Source -Filter "*.md" -ErrorAction SilentlyContinue
    foreach ($file in $files) {
        $destFile = Join-Path $Dest $file.Name
        Copy-Item -Path $file.FullName -Destination $destFile -Force -ErrorAction SilentlyContinue
        Write-Log "  Synced: $($file.Name)" -Level "SUCCESS"
    }
}

function Get-GitCommitCount {
    if (Test-Path $gitCommitCountFile) {
        return Get-Content $gitCommitCountFile -ErrorAction SilentlyContinue
    }
    return 0
}

function Reset-GitCommitCount {
    Set-Content $gitCommitCountFile -Value "0" -Encoding UTF8
}

function Should-CommitGit {
    # 每 15 次同步提交一次 Git（30 分钟）
    $maxCommits = 15
    $currentCount = Get-GitCommitCount
    
    if ($currentCount -ge $maxCommits) {
        Reset-GitCommitCount
        return $true
    }
    
    Increment-GitCommitCount
    return $false
}

function Increment-GitCommitCount {
    $currentCount = Get-GitCommitCount
    Set-Content $gitCommitCountFile -Value ($currentCount + 1) -Encoding UTF8
}

function Commit-ToGit {
    Set-Location $backupPath
    
    $hasChanges = git status --porcelain 2>$null
    if ($hasChanges) {
        git add . 2>$null
        $commitMsg = "🌸 Auto-sync - $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
        git commit -m $commitMsg 2>$null
        git push origin master 2>$null
        Write-Log "  Git commit completed" -Level "SUCCESS"
    } else {
        Write-Log "  No changes, skip Git commit" -Level "INFO"
    }
}

# ============ 会话追踪集成 ============
$SessionTrackerPath = Join-Path $backupPath "session-state\session-tracker.ps1"
if (Test-Path $SessionTrackerPath) {
    Write-Log "Checking session status..." -Level "INFO"
    & $SessionTrackerPath -CheckOnly 2>$null
}

# ============ 主程序 ============
Write-Host "================================" -ForegroundColor Magenta
Write-Host "Linger Auto-Sync v3.0" -ForegroundColor Magenta
Write-Host "================================" -ForegroundColor Magenta
Write-Host ""

Write-Log "Starting sync..." -Level "INFO"

# 1. 同步核心文件
Write-Log "Syncing core files..." -Level "INFO"
if (!(Test-Path $coreBackupPath)) {
    New-Item -ItemType Directory -Force -Path $coreBackupPath | Out-Null
}
Sync-Files -Source $sourcePath -Dest $coreBackupPath

# 2. 同步每日日志
Write-Log "Syncing daily logs..." -Level "INFO"
if (!(Test-Path $dailyBackupPath)) {
    New-Item -ItemType Directory -Force -Path $dailyBackupPath | Out-Null
}
Sync-Files -Source $sourcePath -Dest $dailyBackupPath

# 3. 同步会话记录
Write-Log "Syncing sessions..." -Level "INFO"
if (!(Test-Path $sessionsBackupPath)) {
    New-Item -ItemType Directory -Force -Path $sessionsBackupPath | Out-Null
}
$jsonlFiles = Get-ChildItem $sourcePath -Filter "*.jsonl" -ErrorAction SilentlyContinue
foreach ($file in $jsonlFiles) {
    $destFile = Join-Path $sessionsBackupPath $file.Name
    Copy-Item -Path $file.FullName -Destination $destFile -Force -ErrorAction SilentlyContinue
    Write-Log "  Synced: $($file.Name)" -Level "SUCCESS"
}

# 4. Git 提交（仅在有变更且达到频率限制时）
Write-Log "Checking Git commit..." -Level "INFO"
if (Should-CommitGit) {
    Write-Log "Committing to Git..." -Level "INFO"
    Commit-ToGit
} else {
    $count = Get-GitCommitCount
    Write-Log "  Git commit deferred (count: $count/15)" -Level "INFO"
}

Write-Log "Sync completed!" -Level "SUCCESS"

Write-Host ""
